options(repos = c(CRAN = "https://cloud.r-project.org"))
pkgs <- c(
  "readxl","data.table","dplyr","tidyr","stringr","readr","yaml","fs","here",
  "digest","glue","jsonlite","ggplot2","sf","ranger","Cubist","xgboost","grf",
  "Matrix","future","future.apply","caret","CAST","nnls"
)
missing <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing)) {
  message("Installing missing packages: ", paste(missing, collapse = ", "))
  install.packages(missing, Ncpus = max(1L, parallel::detectCores() - 1L))
} else {
  message("All packages are already installed.")
}
